require 'test_helper'

class UserConfirmEmailJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
