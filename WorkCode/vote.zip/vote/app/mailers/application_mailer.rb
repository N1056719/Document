class ApplicationMailer < ActionMailer::Base
  default from: 'chianghanlung@gmail.com'
  layout 'mailer'
end
